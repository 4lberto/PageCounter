//This is loaded when any page starts loading
chrome.extension.sendRequest({nothing: "null"});
